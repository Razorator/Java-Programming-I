import java.util.Scanner;

public class FromOneToParameter {

    public static void main(String[] args) {
        Scanner scanner = new Scanner(System.in);
        printUntilNumber(Integer.valueOf(scanner.nextLine()));
    }

    public static void printUntilNumber(int number) {
        int x = 0;
        while (x < number) {
            x++;
            System.out.println(x);
        }
    }
}
