
public class AdvancedAstrology {

    public static void printStars(int number) {
        String stars = "";
        while (number > 0) {
            stars = stars + "*";
            number--;
        }
        System.out.print(stars);
        System.out.println("");
    }

    public static void printSpaces(int number) {
        String spaces = "";
        while (number > 0) {
            spaces = spaces + " ";
            number--;
        }
        System.out.print(spaces);
    }

    public static void printTriangle(int size) {
        for (int i = 1; i - 1 < size; i++) {
            printSpaces(size - i);
            printStars(i);
        }
    }

    public static void christmasTree(int height) {
        printSpaces(height - 1);
        printStars(1);
        for (int i = 1; i < height; i++) {
            printSpaces(height - i - 1);
            printStars(i * 2 + 1);
        }
        printSpaces(height - 2);
        printStars(3);
        printSpaces(height - 2);
        printStars(3);
    }

    public static void main(String[] args) {
        // The tests are not checking the main, so you can modify it freely.

        printTriangle(4);
        System.out.println("---");
        christmasTree(4);
        System.out.println("---");
        christmasTree(10);
    }
}
