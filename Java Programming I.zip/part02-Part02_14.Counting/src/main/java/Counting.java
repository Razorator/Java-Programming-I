
import java.util.Scanner;

public class Counting {

    public static void main(String[] args) {
        Scanner scanner = new Scanner(System.in);
        int count = 0;
        for (int x = (Integer.valueOf(scanner.nextLine()) + 1); x != 0; x--) {            
            System.out.println(count);
            count++;
        }
    }   
}
