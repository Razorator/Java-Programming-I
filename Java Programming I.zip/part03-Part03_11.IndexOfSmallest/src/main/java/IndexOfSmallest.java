
import java.util.ArrayList;
import java.util.Scanner;

public class IndexOfSmallest {

    public static void main(String[] args) {
        Scanner scanner = new Scanner(System.in);
        ArrayList<Integer> list = new ArrayList<>();
        while (true) {
            int x = Integer.valueOf(scanner.nextLine());
            if (x != 9999) {
                list.add(x);
            } else {
                break;
            }
        }

        int smallest = list.get(0);
        ArrayList<Integer> location = new ArrayList<>(0);

        for (int i = 0; i < list.size(); i++) {
            if (smallest > list.get(i)) {
                location = new ArrayList<>();
                location.add(i);
                smallest = list.get(i);
            } else if (smallest == list.get(i)) {
                location.add(i);
            }
        }
        System.out.println("Smallest number: " + smallest);
        for (int i = 0; i < location.size(); i++) {
            System.out.println("Found at index: " + location.get(i));
        }
        // after that, the program prints the smallest number
        // and its index -- the smallest number
        // might appear multiple times

    }
}
