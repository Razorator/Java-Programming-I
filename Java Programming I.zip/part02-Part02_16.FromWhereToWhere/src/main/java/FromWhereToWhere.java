
import java.util.Scanner;

public class FromWhereToWhere {

    public static void main(String[] args) {
        Scanner scanner = new Scanner(System.in);
        System.out.println("Where to?");
        int to = Integer.valueOf(scanner.nextLine());
        System.out.println("Where from?");
        int from = Integer.valueOf(scanner.nextLine());
        for (int x = from; to != (from - 1); from++) {
            if (to < from) {
                return;
            } else {
                System.out.println(from);
            }
        }
    }
}
// Write your program here


