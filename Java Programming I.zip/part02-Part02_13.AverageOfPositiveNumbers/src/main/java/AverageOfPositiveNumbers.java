
import java.util.Scanner;

public class AverageOfPositiveNumbers {

    public static void main(String[] args) {
        Scanner scanner = new Scanner(System.in);
        int pos = 0;
        int sum = 0;
        while (true) {
            int x = Integer.valueOf(scanner.nextLine());
            if (x > 0) {
                pos = pos + 1;
                sum = sum + x;
                continue;
            } else if (x != 0) {
                continue;
            } else if (pos != 0) {
                System.out.println((double) sum / pos);
            } else {
                System.out.println("Cannot calculate the average");
            }
            break;
        }
    }
}
